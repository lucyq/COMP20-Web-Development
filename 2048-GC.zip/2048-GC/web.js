//	COMP 20 Assignment #4
// 	2048 Game Center



// Initializing express
var express = require("express");
var app = express();
app.set('port', process.env.PORT || 3000);

// Initializing mongo and setting up a connection to a MongoDB
var mongo = require('mongodb');
var mongoUri = process.env.MONGOLAB_URI ||
	process.env.MONGOHQ_URL ||
	'mongodb://localhost/mydb';

// other dependencies
var http = require ("http");
var path = require ("path");
app.use(express.static(path.join(__dirname, 'public')));

//var routes = require('./routes');


// app
app.set('port', process.env.PORT || 3000);
//app.use(express.json());
//app.use(express.urlencoded());
var bodyParser = require("body-parser");
app.use(bodyParser());


	


app.get('/', function (request, response) {
	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (err, col) {
			var tableData = " ";
			col.find().sort({score: -1}).limit(100).toArray(function (err, items) {
				if (!err) {
					tableData += "<!DOCTYPE HTML><html><head><link rel='stylesheet' type='text/css' href ='style.css'></link><title>2048 Game Center</title></head><body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
					for (var count = 0; count < items.length; count++) {
						tableData += "<tr><td>" + items[count].username+ 
							     "</td><td>" + items[count].score + 
							     "</td><td>" + items[count].created_at + "</td></tr>";
					}
					tableData += "</table></body></html>";
				response.send(tableData);
				}
			});
		});
	});
});


// Get user name
// Connect database
// Return relevant info --- JSON records for user 
app.get('/scores.json', function(request, response) {
	// enable cross origin sharing
	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");

  	// get username
  	var name = request.query.username;
  	if (name === undefined) {
  		response.send('[]');
  	}
  	else {
  		// connect database
		mongo.Db.connect(mongoUri, function (err, db) {
			db.collection("scores", function (err, col) {
				// find information
				col.find({"username": name}).toArray(function (err, items) {
					if (!err) {
						response.send(items);
					}
				});
			});
		});
	}
});


// posting and adding info to the database
app.post('/submit.json', function (request, response) {
	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	mongo.Db.connect(mongoUri, function (err, db) {
			db.collection("scores", function (err, collection) {
			var name = request.body.username;
			var score = request.body.score;
			var grid = request.body.grid;
			// variables used

			if (name === undefined ||
				score === undefined || 
				grid === undefined) {
				response.send("Nay!");
			} else {
				score = parseInt(score);
				var currDate = new Date();
		    	var timestamp = (currDate.getUTCMonth() + 1) + "/" + 
		    					currDate.getUTCDate() + "/" +
               					currDate.getUTCFullYear() + " - " + 
               					currDate.getHours() + ":" + 
                    			currDate.getMinutes() + ":" + 
                    			currDate.getSeconds();
				collection.insert({"username": name, "score": score, "grid": grid, "created_at": timestamp}, function (error, r){});
				response.send("Yay!");
			}
		});
	});
});



http.createServer(app).listen(app.get('port'), function() {
	console.log("Listening in on port " + app.get('port'));
});