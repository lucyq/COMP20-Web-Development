Assignment #4 Game Center
Lucy Qin

Implementation
-Properly posts information after game ends to the database
-Properly retrieves data and displays scores in the game center
-Properly retrieves a JSON object for the username specified and returns an empty JSON object if the name or if nothing is specificed

Collaboration
-Did not collaborate with anyone but received help from TA Jasper and Ming

Hours Spent: 20

-When the app is running locally, scores and grids are stored in a collection called "scores" that is in a local database
-When the app is running on heroku, scores and grids are stored in a collection in a database hosted by mongolabs
-The collection is a larger JSON object. Scores and grids are added to this JSON object each time 
-This is implemented in the web.js file


-In order to send the final score and grid my web application, the gamecenter.js file used by the 2048 game had to be modified. Information is posted from the game.



